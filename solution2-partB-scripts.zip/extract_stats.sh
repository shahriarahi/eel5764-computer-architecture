#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/gem5"
for model in timing o3; do
  stats="m5out-assignment2-$model/stats.txt"
  if [[ ! -f "$stats" ]]; then echo "Missing $stats" >&2; exit 1; fi
  echo "=== $model ==="
  grep -E '^(sim_ticks|simTicks|system\.cpu\.numCycles|system\.cpu\.(ipc|cpi)|system\.cpu\.dcache\.overallMisses::total)' "$stats" || true
done
